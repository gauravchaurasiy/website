


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?> <a href="<?php echo url("/events/create");?>"><button type="button" id="edit12"  class="btn btn-primary"  >Add Event </button></a></div>
                 <?php echo e(whataspp($id='1',$send='1')); ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
 
                </div>
                <div id="msg"> </div>
                      
<table id="table" class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Create at</th>
            <th>User Type</th>
            <th width="300px;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($data) && $data->count()): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($value->id); ?>">
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->created_at); ?></td>
                    <td><?php echo e($value->user_type_id==1?"Admin":"User"); ?></td>
                    <td>
                        <button onclick="delete_data(<?php echo e($value->id); ?>)" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
   
<?php echo $data->links(); ?>

        </div>
    </div>
</div>
<script type="text/javascript">
 	function delete_data(a) {
 		 
 		$.ajax({
type: "POST", 
url:"/user_delete",
async: true,
data: { _token: $('meta[name="csrf-token"]').attr('content'), id: a },
 success:function(data){
 	console.log(data);
            $("#msg").html("");

                if (data.msg==1) {
            $("#msg").html("user deleted successfully");

                }else{
            $("#msg").html("user not deleted");
 
                }
           $('table#table tr#'+a).remove();
         }
});
return false;


	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php7.4\htdocs\gaurav\website1\resources\views/admin_home_user.blade.php ENDPATH**/ ?>