

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?> <a href="<?php echo url("/events");?>"><button type="button" id="edit12"  class="btn btn-primary"  > Event </button></a></div>
                 
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
 

                </div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

                       <?php

                       //dd($data["events"]->id);

                       ?>     

            <form action="<?php echo URL("/events/{$data["events"]->id}");?>" method="POST" role="form" >
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('PUT'); ?>

              <div class="card-body">
                
              <input type="hidden" name="id" value="<?php echo e($data["events"]->id); ?>">

                  <div class="form-group">
                  <label>Event Name</label> 
                  <input name="events" value="<?php echo e($data["events"]->name); ?>"   type="text" class="form-control events" id="events" placeholder="Enter events name">

                  </div>

                  <div class="form-group">
                  <label>Start time</label>
                  <input name="start_time" type="datetime" value="<?php echo e($data["events"]->start_at); ?>"   class="form-control start_time" id="start_time" placeholder="Enter Start time">

                  </div>

                  <div class="form-group">
                  <label>end time</label>
                  <input name="end_time" type="datetime" value="<?php echo e($data["events"]->end_at); ?>"   class="form-control end_time" id="end_time" placeholder="Enter end time">

                  </div>

                  <div class="form-group">
                  <label></label>
                
                <button type="Submit" id="Submit"  class="btn btn-primary"  >Save Event </button>

                  </div>


              </div>
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php7.4\htdocs\gaurav\website1\resources\views/edit_events.blade.php ENDPATH**/ ?>