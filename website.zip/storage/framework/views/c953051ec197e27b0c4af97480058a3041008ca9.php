

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?> <a href="<?php echo url("/events/create");?>"><button type="button" id="edit12"  class="btn btn-primary"  >Add Event </button></a></div>
                  
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
 <?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
                </div>
                            <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                   <th>Sr no</th>
                    <th>Name</th>
                    <th>Start At</th>
                    <th>End At</th>
                    <th>Create Date</th>
                    <th>control</th>
                    <th>Communication</th>

                  </tr>
                  </thead>
                  <tbody>
<?php $i=1  ?>

<?php $__currentLoopData = $data["events"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($member->name); ?></td>
                    <td><?php echo e($member->start_at); ?></td>
                    <td> <?php echo e($member->end_at); ?></td>
                    <td> <?php echo e($member->created_at); ?></td>
                    <td>
                        <a href="<?php echo url("/events/{$member->id}/edit/");?>/"><button type="button" id="edit12"  class="btn btn-primary"  >Edit </button></a>
                        <form action="<?php echo url("/events/{$member->id}/");?>/" method="post">
                            
                            <?php echo method_field("DELETE"); ?>
                            <?php echo csrf_field(); ?>
                             <button type="submit" id="delete" name="id" data-id="<?php echo e($member->id); ?>" data-name="<?php echo e($member->name); ?>" class="delete_cat btn btn-primary delete<?php echo e($member->id); ?>"  >Delete</button>
                        </form>
                     
                    </td>
                    <td><form action="<?php echo url("/add_communication/{$member->id}/");?>/" method="post">
                            
                             
                            <?php echo csrf_field(); ?>
                             <button type="submit" id="delete" name="id" data-id="<?php echo e($member->id); ?>" data-name="<?php echo e($member->name); ?>" class="delete_cat btn btn-primary delete<?php echo e($member->id); ?>"  >Add</button>
                        </form></td>
                  </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
                    
                 
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Sr no</th>
                    <th>Name</th>
                    <th>Start At</th>
                    <th>End At</th>
                    <th>Create Date</th>
                    <th>control</th>
                    <th>Communication</th>

                  </tr>
                  </tfoot>
                </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php7.4\htdocs\gaurav\website1\resources\views/admin_home.blade.php ENDPATH**/ ?>