-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2020 at 04:44 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `communications`
--

CREATE TABLE `communications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_at` datetime NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT 0,
  `sms` int(11) NOT NULL DEFAULT 0,
  `email` int(11) NOT NULL DEFAULT 0,
  `firebase` int(11) NOT NULL DEFAULT 0,
  `whatsapp` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 0,
  `delete_at` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `communications`
--

INSERT INTO `communications` (`id`, `name`, `start_at`, `event_id`, `sms`, `email`, `firebase`, `whatsapp`, `active`, `delete_at`, `created_at`, `updated_at`) VALUES
(3, 'aaaagaurav', '2020-12-31 00:00:00', 3, 1, 1, 1, 1, 0, '0', '2020-07-26 13:58:46', '2020-07-28 04:18:16'),
(6, 'aaaagaurav', '2020-12-31 00:00:00', 6, 1, 1, 1, 1, 0, '0', '2020-07-26 14:24:14', '2020-07-28 04:10:17'),
(10, 'aaaa', '2020-12-31 00:00:00', 2, 1, 1, 1, 1, 0, '0', '2020-07-26 14:36:53', '2020-07-26 14:36:53'),
(11, 'test12345', '2020-12-31 00:00:00', 11, 1, 1, 1, 1, 0, '0', '2020-07-28 04:03:23', '2020-07-28 04:04:59'),
(12, 'test', '2020-12-31 00:00:00', 2, 1, 1, 1, 1, 0, '0', '2020-07-28 04:03:51', '2020-07-28 04:03:51'),
(13, 'test31', '2020-12-31 00:00:00', 13, 1, 1, 1, 1, 0, '0', '2020-07-28 04:04:08', '2020-07-28 04:04:26'),
(14, 'gaurav3 14 id', '2020-12-31 00:00:00', 14, 1, 1, 1, 1, 0, '0', '2020-07-28 04:07:35', '2020-07-28 04:07:54'),
(16, 'gaurav', '2020-12-31 00:00:00', 3, 1, 1, 1, 1, 0, '0', '2020-07-28 04:35:28', '2020-07-28 04:35:28'),
(17, 'gaurav123', '2020-12-31 00:00:00', 3, 1, 1, 1, 0, 0, '0', '2020-07-28 04:42:19', '2020-07-28 04:42:19'),
(18, 'gaurav123', '2020-12-31 00:00:00', 3, 1, 1, 1, 0, 0, '0', '2020-07-28 04:42:41', '2020-07-28 04:42:41'),
(19, 'pooo', '2020-12-31 00:00:00', 3, 0, 1, 1, 1, 0, '0', '2020-07-28 04:43:28', '2020-07-28 04:43:28'),
(22, 'aaaa', '2020-12-31 00:00:00', 10, 1, 1, 1, 1, 0, '0', '2020-07-30 09:07:52', '2020-07-30 09:07:52');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `delete_at` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `start_at`, `end_at`, `active`, `delete_at`, `created_at`, `updated_at`) VALUES
(10, 'aaa12121212', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-26 06:10:43', '2020-07-30 09:07:40'),
(11, 'dasda', '2020-12-30 00:00:00', '2021-11-01 00:00:00', 0, 0, '2020-07-28 03:26:28', '2020-07-28 03:26:28'),
(12, 'dasda', '2020-12-30 00:00:00', '2021-11-01 00:00:00', 0, 0, '2020-07-28 03:26:58', '2020-07-28 03:26:58'),
(13, 'sasa', '2020-12-31 00:00:00', '2021-12-31 00:00:00', 0, 0, '2020-07-28 03:27:33', '2020-07-28 03:27:33'),
(14, 'aaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:02:58', '2020-07-28 04:02:58'),
(15, 'aaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:21:39', '2020-07-28 04:21:39'),
(16, 'events store', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:22:32', '2020-07-28 04:22:32'),
(17, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:23:46', '2020-07-28 04:23:46'),
(18, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:24:46', '2020-07-28 04:24:46'),
(19, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:24:58', '2020-07-28 04:24:58'),
(20, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:25:11', '2020-07-28 04:25:11'),
(21, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:26:05', '2020-07-28 04:26:05'),
(22, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:26:19', '2020-07-28 04:26:19'),
(23, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:26:43', '2020-07-28 04:26:43'),
(24, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:27:22', '2020-07-28 04:27:22'),
(25, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:27:59', '2020-07-28 04:27:59'),
(26, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:28:06', '2020-07-28 04:28:06'),
(27, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:28:44', '2020-07-28 04:28:44'),
(28, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:30:15', '2020-07-28 04:30:15'),
(29, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:30:49', '2020-07-28 04:30:49'),
(30, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:31:04', '2020-07-28 04:31:04'),
(31, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:31:21', '2020-07-28 04:31:21'),
(32, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:32:36', '2020-07-28 04:32:36'),
(33, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:32:51', '2020-07-28 04:32:51'),
(34, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:33:16', '2020-07-28 04:33:16'),
(35, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:33:33', '2020-07-28 04:33:33'),
(36, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:33:36', '2020-07-28 04:33:36'),
(37, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:33:37', '2020-07-28 04:33:37'),
(38, 'aaaaaaaaaaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 04:34:08', '2020-07-28 04:34:08'),
(39, 'gai', '2020-12-31 00:00:00', '2020-11-30 00:00:00', 0, 0, '2020-07-28 11:58:20', '2020-07-28 11:58:20'),
(40, 'aaaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 12:34:56', '2020-07-28 12:34:56'),
(41, 'ssssssssssssssssssssssssssssss', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 12:38:03', '2020-07-28 12:38:03'),
(42, 'ssss', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 13:35:54', '2020-07-28 13:35:54'),
(43, 'ssss', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-28 13:36:43', '2020-07-28 13:36:43'),
(44, 'aa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-29 13:32:24', '2020-07-29 13:32:24'),
(45, 'aaa', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-29 13:36:32', '2020-07-29 13:36:32'),
(46, 'test', '2020-12-31 00:00:00', '2020-12-31 00:00:00', 0, 0, '2020-07-30 09:07:16', '2020-07-30 09:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `whatsapp` int(1) NOT NULL DEFAULT 0,
  `sms` int(1) NOT NULL DEFAULT 0,
  `email` int(1) NOT NULL DEFAULT 0,
  `firebase` int(1) NOT NULL DEFAULT 0,
  `user_id` int(1) NOT NULL DEFAULT 0,
  `events_id` int(11) NOT NULL DEFAULT 0,
  `communication_id` int(11) NOT NULL DEFAULT 0,
  `data_log` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `created_at`, `updated_at`, `whatsapp`, `sms`, `email`, `firebase`, `user_id`, `events_id`, `communication_id`, `data_log`) VALUES
(1, '2020-07-28 02:30:54', '2020-07-28 02:30:54', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(2, '2020-07-28 02:30:55', '2020-07-28 02:30:55', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(3, '2020-07-28 03:16:28', '2020-07-28 03:16:28', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(4, '2020-07-28 03:16:29', '2020-07-28 03:16:29', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(5, '2020-07-28 03:18:58', '2020-07-28 03:18:58', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(6, '2020-07-28 03:18:59', '2020-07-28 03:18:59', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(7, '2020-07-28 03:22:43', '2020-07-28 03:22:43', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(8, '2020-07-28 03:22:44', '2020-07-28 03:22:44', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(9, '2020-07-28 03:28:20', '2020-07-28 03:28:20', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(10, '2020-07-28 03:28:20', '2020-07-28 03:28:20', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(11, '2020-07-28 03:48:57', '2020-07-28 03:48:57', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(12, '2020-07-28 03:48:58', '2020-07-28 03:48:58', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(13, '2020-07-28 03:50:10', '2020-07-28 03:50:10', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(14, '2020-07-28 03:50:11', '2020-07-28 03:50:11', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(15, '2020-07-28 03:50:27', '2020-07-28 03:50:27', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(16, '2020-07-28 03:50:27', '2020-07-28 03:50:27', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(17, '2020-07-28 03:50:44', '2020-07-28 03:50:44', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(18, '2020-07-28 03:50:45', '2020-07-28 03:50:45', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(19, '2020-07-28 03:53:50', '2020-07-28 03:53:50', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(20, '2020-07-28 03:53:51', '2020-07-28 03:53:51', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(21, '2020-07-28 03:56:04', '2020-07-28 03:56:04', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(22, '2020-07-28 03:56:04', '2020-07-28 03:56:04', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(23, '2020-07-28 04:00:33', '2020-07-28 04:00:33', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(24, '2020-07-28 04:00:34', '2020-07-28 04:00:34', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(25, '2020-07-28 04:01:52', '2020-07-28 04:01:52', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(26, '2020-07-28 04:01:52', '2020-07-28 04:01:52', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(27, '2020-07-28 04:03:00', '2020-07-28 04:03:00', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(28, '2020-07-28 04:03:01', '2020-07-28 04:03:01', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(29, '2020-07-28 04:04:31', '2020-07-28 04:04:31', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(30, '2020-07-28 04:04:33', '2020-07-28 04:04:33', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(31, '2020-07-28 04:05:03', '2020-07-28 04:05:03', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(32, '2020-07-28 04:05:04', '2020-07-28 04:05:04', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(33, '2020-07-28 04:06:26', '2020-07-28 04:06:26', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(34, '2020-07-28 04:06:27', '2020-07-28 04:06:27', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(35, '2020-07-28 04:06:54', '2020-07-28 04:06:54', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(36, '2020-07-28 04:06:55', '2020-07-28 04:06:55', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(37, '2020-07-28 04:07:03', '2020-07-28 04:07:03', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(38, '2020-07-28 04:07:04', '2020-07-28 04:07:04', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(39, '2020-07-28 04:08:20', '2020-07-28 04:08:20', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(40, '2020-07-28 04:08:20', '2020-07-28 04:08:20', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(41, '2020-07-28 04:10:24', '2020-07-28 04:10:24', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(42, '2020-07-28 04:10:25', '2020-07-28 04:10:25', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(43, '2020-07-28 04:21:14', '2020-07-28 04:21:14', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(44, '2020-07-28 04:21:14', '2020-07-28 04:21:14', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(45, '2020-07-28 04:21:25', '2020-07-28 04:21:25', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(46, '2020-07-28 04:21:26', '2020-07-28 04:21:26', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(47, '2020-07-28 04:21:41', '2020-07-28 04:21:41', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(48, '2020-07-28 04:21:42', '2020-07-28 04:21:42', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(49, '2020-07-28 04:22:34', '2020-07-28 04:22:34', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(50, '2020-07-28 04:22:35', '2020-07-28 04:22:35', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(51, '2020-07-28 04:34:11', '2020-07-28 04:34:11', 1, 0, 0, 0, 1, 3, 3, '\"|||\"'),
(52, '2020-07-28 04:34:12', '2020-07-28 04:34:12', 1, 0, 0, 0, 2, 3, 3, '\"|||\"'),
(53, '2020-07-28 12:04:32', '2020-07-28 12:04:32', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(54, '2020-07-28 12:04:34', '2020-07-28 12:04:34', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(55, '2020-07-28 12:04:36', '2020-07-28 12:04:36', 0, 1, 1, 1, 3, 6, 6, '\"|||\"'),
(56, '2020-07-28 12:05:12', '2020-07-28 12:05:12', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(57, '2020-07-28 12:05:14', '2020-07-28 12:05:14', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(58, '2020-07-28 12:05:16', '2020-07-28 12:05:16', 0, 1, 1, 1, 3, 6, 6, '\"|||\"'),
(59, '2020-07-28 12:15:33', '2020-07-28 12:15:33', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(60, '2020-07-28 12:15:36', '2020-07-28 12:15:36', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(61, '2020-07-28 12:15:38', '2020-07-28 12:15:38', 0, 1, 1, 1, 3, 6, 6, '\"|||\"'),
(62, '2020-07-28 12:16:19', '2020-07-28 12:16:19', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(63, '2020-07-28 12:16:21', '2020-07-28 12:16:21', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(64, '2020-07-28 12:16:23', '2020-07-28 12:16:23', 0, 1, 1, 1, 3, 6, 6, '\"|||\"'),
(65, '2020-07-28 12:17:03', '2020-07-28 12:17:03', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(66, '2020-07-28 12:17:05', '2020-07-28 12:17:05', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(67, '2020-07-28 12:17:07', '2020-07-28 12:17:07', 0, 1, 1, 1, 3, 6, 6, '\"|||\"'),
(68, '2020-07-28 12:18:08', '2020-07-28 12:18:08', 0, 1, 1, 1, 1, 6, 6, '\"|||\"'),
(69, '2020-07-28 12:18:10', '2020-07-28 12:18:10', 0, 1, 1, 1, 2, 6, 6, '\"|||\"'),
(70, '2020-07-28 12:18:13', '2020-07-28 12:18:13', 0, 1, 1, 1, 3, 6, 6, '\"|||\"');

-- --------------------------------------------------------

--
-- Table structure for table `log_communications`
--

CREATE TABLE `log_communications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comm_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log_communications`
--

INSERT INTO `log_communications` (`id`, `created_at`, `updated_at`, `event_id`, `data`, `comm_id`) VALUES
(1, '2020-07-28 04:43:28', '2020-07-28 04:43:28', 3, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"pooo\",\"start_time\":\"2020-12-31\",\"sms\":\"0\",\"email\":\"1\",\"firebase\":\"1\",\"whatsapp\":\"1\"}', 19),
(2, '2020-07-28 12:03:10', '2020-07-28 12:03:10', 6, '{\"_token\":\"ci1XuDrhVr7FREirl2sPF8vwgz4IgIip1ZSJBBWO\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"sms\":\"1\",\"email\":\"1\",\"firebase\":\"1\",\"whatsapp\":\"1\"}', 20),
(3, '2020-07-29 13:33:12', '2020-07-29 13:33:12', 8, '{\"_token\":\"X0g8yQ0FXHe0xMIZq47ZiefwMuk34ZzP4ttFRGxa\",\"_method\":\"POST\",\"events\":\"aaaa\",\"start_time\":\"2020-12-31\",\"sms\":\"1\",\"email\":\"1\",\"firebase\":\"1\",\"whatsapp\":\"1\"}', 21),
(4, '2020-07-30 09:07:52', '2020-07-30 09:07:52', 10, '{\"_token\":\"4wMLJMBvvZgbT26M9OiOgO3O5dwI9TWXAaCgIRvf\",\"_method\":\"POST\",\"events\":\"aaaa\",\"start_time\":\"2020-12-31\",\"sms\":\"1\",\"email\":\"1\",\"firebase\":\"1\",\"whatsapp\":\"1\"}', 22);

-- --------------------------------------------------------

--
-- Table structure for table `log_events`
--

CREATE TABLE `log_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `event_id` int(11) NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log_events`
--

INSERT INTO `log_events` (`id`, `created_at`, `updated_at`, `event_id`, `data`) VALUES
(1, '2020-07-01 10:01:41', NULL, 27, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(2, '2020-07-28 04:33:16', NULL, 34, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(3, '2020-07-28 04:33:33', NULL, 35, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(4, '2020-07-28 04:33:36', NULL, 36, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(5, '2020-07-28 04:33:37', NULL, 37, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(6, '2020-07-28 04:34:09', NULL, 38, '{\"_token\":\"dq6tiRBfgqpMutdcsEY6Jh0x7WsVrfyKPVBW1abB\",\"_method\":\"POST\",\"events\":\"aaaaaaaaaaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(7, '2020-07-28 11:58:20', NULL, 39, '{\"_token\":\"ci1XuDrhVr7FREirl2sPF8vwgz4IgIip1ZSJBBWO\",\"_method\":\"POST\",\"events\":\"gai\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-11-30\"}'),
(8, '2020-07-28 12:34:56', NULL, 40, '{\"_token\":\"UFIbhPHa948FK157oe63zYx0dVaPtj5Nw0r21pCr\",\"_method\":\"POST\",\"events\":\"aaaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(9, '2020-07-28 12:38:03', NULL, 41, '{\"_token\":\"LBcETqaQdcXxzXBGMLIAs4GMTBoy1mwkv03Bsacs\",\"_method\":\"POST\",\"events\":\"ssssssssssssssssssssssssssssss\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(10, '2020-07-28 13:35:54', NULL, 42, '{\"_token\":\"Mkf6jJg5f2tPBMH8Y95EGQEAXLZAuvrS3qmOVbmN\",\"_method\":\"POST\",\"events\":\"ssss\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(11, '2020-07-28 13:36:43', NULL, 43, '{\"_token\":\"Mkf6jJg5f2tPBMH8Y95EGQEAXLZAuvrS3qmOVbmN\",\"_method\":\"POST\",\"events\":\"ssss\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(12, '2020-07-29 13:32:24', NULL, 44, '{\"_token\":\"X0g8yQ0FXHe0xMIZq47ZiefwMuk34ZzP4ttFRGxa\",\"_method\":\"POST\",\"events\":\"aa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(13, '2020-07-29 13:36:32', NULL, 45, '{\"_token\":\"X0g8yQ0FXHe0xMIZq47ZiefwMuk34ZzP4ttFRGxa\",\"_method\":\"POST\",\"events\":\"aaa\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}'),
(14, '2020-07-30 09:07:16', NULL, 46, '{\"_token\":\"4wMLJMBvvZgbT26M9OiOgO3O5dwI9TWXAaCgIRvf\",\"_method\":\"POST\",\"events\":\"test\",\"start_time\":\"2020-12-31\",\"end_time\":\"2020-12-31\"}');

-- --------------------------------------------------------

--
-- Table structure for table `log_user_events`
--

CREATE TABLE `log_user_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `event_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log_user_events`
--

INSERT INTO `log_user_events` (`id`, `event_name`, `event_id`, `user_id`, `user_name`, `user_email`, `start_at`, `end_at`, `created_at`, `updated_at`) VALUES
(17, 'aaaa', 3, 2, 'gaurav', 'c.gaurav914@gmail.com', '2020-12-31 00:00:00', '2020-12-31 00:00:00', '2020-07-28 08:23:23', '2020-07-28 08:23:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_07_25_184350_create_events_table', 2),
(5, '2020_07_25_191158_create_logs_table', 2),
(8, '2020_07_26_151859_create_communications_table', 3),
(9, '2020_07_28_081801_create_log_events_table', 4),
(10, '2020_07_28_081820_create_log_communications_table', 4),
(11, '2020_07_28_124708_create_log_user_events_table', 5),
(12, '2016_06_01_000001_create_oauth_auth_codes_table', 6),
(13, '2016_06_01_000002_create_oauth_access_tokens_table', 6),
(14, '2016_06_01_000003_create_oauth_refresh_tokens_table', 6),
(15, '2016_06_01_000004_create_oauth_clients_table', 6),
(16, '2016_06_01_000005_create_oauth_personal_access_clients_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('2e78e7deadda331572618ffeffdc727e6075562c9897f7042f5ca127df2e97354881d1d9faeadfe3', 11, 1, 'MyApp', '[]', 0, '2020-07-30 09:10:00', '2020-07-30 09:10:00', '2021-07-30 14:40:00'),
('4760e4fb7a559523c3bca4bd339bbb95dc5edca065756484c268dbbfa4fa923da2b230013d77812b', 3, 1, 'MyApp', '[]', 0, '2020-07-28 09:44:38', '2020-07-28 09:44:38', '2021-07-28 15:14:38'),
('65d5787100134a6f83a2eb4786cba1efdc1d34f9a9e7ab3db02b9108d1c5c3ca5672a876de340c68', 2, 1, 'MyApp', '[]', 0, '2020-07-28 11:28:44', '2020-07-28 11:28:44', '2021-07-28 16:58:44'),
('6b4b3c36d1b6a53a4632600a1bcd2dd56ee5df34b1d64f4b3d509b08e35a3841d36f98746019d484', 3, 1, 'MyApp', '[]', 0, '2020-07-28 11:28:18', '2020-07-28 11:28:18', '2021-07-28 16:58:18'),
('9bcff8fc1764f49be4aa54705fba99a61f7b5dd51c5e4041d5e33cbe58397a539ffe1ea650b54373', 3, 1, 'MyApp', '[]', 0, '2020-07-28 11:28:17', '2020-07-28 11:28:17', '2021-07-28 16:58:17');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'TyUue1XsWnbkXQYi943xqsdAx8bAHijqLaPnagjV', NULL, 'http://localhost', 1, 0, 0, '2020-07-28 08:50:00', '2020-07-28 08:50:00'),
(2, NULL, 'Laravel Password Grant Client', 'IIcuCz0R215l0AFdOvfBQDAxkfhqh6bgTn4JLz7Q', 'users', 'http://localhost', 0, 1, 0, '2020-07-28 08:51:24', '2020-07-28 08:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-07-28 08:50:01', '2020-07-28 08:50:01');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type_id` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `user_type_id`) VALUES
(11, 'gaurav', 'c.gaurav914@gmail.com', NULL, '$2y$10$B2hpFVB4okarpIKvNeu0EO3xPTDVNNtyi1A.cOLMH0XxZTgWSXQ9G', '', '2020-07-25 12:45:12', '2020-07-25 12:45:12', 1),
(12, 'gaurav', 'c.ssss@gmail.com', NULL, '$2y$10$B2hpFVB4okarpIKvNeu0EO3xPTDVNNtyi1A.cOLMH0XxZTgWSXQ9G', '', '2020-07-25 12:45:12', '2020-07-25 12:45:12', 1),
(13, 'Shubham Chaurasiya', 'shubh.ex92@gmail.com', NULL, '$2y$10$knrsXmC24vJBLqFO3fpngOyO7jEp4f.MlXDhTr65d2byEuXCg/BGq', NULL, '2020-07-28 13:26:45', '2020-07-28 13:26:45', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `communications`
--
ALTER TABLE `communications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_communications`
--
ALTER TABLE `log_communications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_events`
--
ALTER TABLE `log_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_user_events`
--
ALTER TABLE `log_user_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `communications`
--
ALTER TABLE `communications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `log_communications`
--
ALTER TABLE `log_communications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `log_events`
--
ALTER TABLE `log_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `log_user_events`
--
ALTER TABLE `log_user_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
