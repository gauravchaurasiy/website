@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }} <a href="<?php echo url("/events/create");?>"><button type="button" id="edit12"  class="btn btn-primary"  >Add Event </button></a></div>
                  
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
 @if(Session::has('message'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
@endif
                </div>
                            <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                   <th>Sr no</th>
                    <th>Name</th>
                    <th>Start At</th>
                    <th>End At</th>
                    <th>Create Date</th>
                    <th>control</th>
                    <th>Communication</th>

                  </tr>
                  </thead>
                  <tbody>
@php $i=1  @endphp

@foreach($data["events"] as $member)

<tr>
                    <td>{{$i++}}</td>
                    <td>{{$member->name}}</td>
                    <td>{{$member->start_at}}</td>
                    <td> {{$member->end_at}}</td>
                    <td> {{$member->created_at}}</td>
                    <td>
                        <a href="<?php echo url("/events/{$member->id}/edit/");?>/"><button type="button" id="edit12"  class="btn btn-primary"  >Edit </button></a>
                        <form action="<?php echo url("/events/{$member->id}/");?>/" method="post">
                            
                            @method("DELETE")
                            @csrf
                             <button type="submit" id="delete" name="id" data-id="{{$member->id}}" data-name="{{$member->name}}" class="delete_cat btn btn-primary delete{{$member->id}}"  >Delete</button>
                        </form>
                     
                    </td>
                    <td><form action="<?php echo url("/add_communication/{$member->id}/");?>/" method="post">
                            
                             
                            @csrf
                             <button type="submit" id="delete" name="id" data-id="{{$member->id}}" data-name="{{$member->name}}" class="delete_cat btn btn-primary delete{{$member->id}}"  >Add</button>
                        </form></td>
                  </tr>

@endforeach

                  
                    
                 
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Sr no</th>
                    <th>Name</th>
                    <th>Start At</th>
                    <th>End At</th>
                    <th>Create Date</th>
                    <th>control</th>
                    <th>Communication</th>

                  </tr>
                  </tfoot>
                </table>
        </div>
    </div>
</div>
@endsection
