@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }} <a href="<?php echo url("/events");?>"><button type="button" id="edit12"  class="btn btn-primary"  > Event </button></a></div>
                 
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
 

                </div>
                            
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

            <form action="<?php echo URL("/edit_communication/{$data["id"]}");?>" method="POST" role="form" >
                   @csrf
                   @method('POST')

              <div class="card-body">
                
 
                  <div class="form-group">
                  <label>Event Name</label>
                  <input name="events" value="{{$data['events']->name}}"  type="text" class="form-control events" id="events" placeholder="Enter events name">

                  </div>

                  <div class="form-group">
                  <label>Start time</label>
                  <input name="start_time" value="{{$data['events']->start_at}}"  type="datetime"  class="form-control start_time" id="start_time" placeholder="Enter Start time">

                  </div>
 
                  <div class="form-group">
                  <label>SMS</label>
                  <select name="sms" class="form-control select2" style="width: 100%;">
                    <option value="0" selected="selected">----Select----</option>
                    <option value="1" {{$data['events']->sms==1?'selected':'no'}} >Yes</option>
                    <option value="0" {{$data['events']->sms==0?'selected':'no'}} >No</option>
                  </select>
                  </div>
                  <div class="form-group">
                  <label>Email</label>
                  <select name="email" class="form-control select2" style="width: 100%;">
                    <option value="0" selected="selected">----Select----</option>
                    <option value="1" {{$data['events']->email==1?'selected':'no'}} >Yes</option>
                    <option value="0" {{$data['events']->email==0?'selected':'no'}} >No</option>
                
 
                  </select>
                  </div>
                  <div class="form-group">
                  <label>Firebase notifications</label>
                  <select name="firebase" class="form-control select2" style="width: 100%;">
                    <option value="0" selected="selected">----Select----</option>
                    <option value="1" {{$data['events']->firebase==1?'selected':'no'}} >Yes</option>
                    <option value="0" {{$data['events']->firebase==0?'selected':'no'}} >No</option>
                
 
                  </select>
                  </div>
                   <div class="form-group">
                  <label>Whatsapp</label>
                  <select name="whatsapp" class="form-control select2" style="width: 100%;">
                    <option value="0" selected="selected">----Select----</option>
                    <option value="1" {{$data['events']->whatsapp==1?'selected':'no'}} >Yes</option>
                    <option value="0" {{$data['events']->whatsapp==0?'selected':'no'}} >No</option>
                
 
                  </select>
                  </div>

                  <div class="form-group">
                  <label></label>
                
                <button type="Submit" id="Submit"  class="btn btn-primary"  >Add Event </button>

                  </div>


              </div>
            </form>
    </div>
</div>
@endsection
