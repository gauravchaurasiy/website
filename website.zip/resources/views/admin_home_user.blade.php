
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }} <a href="<?php echo url("/events/create");?>"><button type="button" id="edit12"  class="btn btn-primary"  >Add Event </button></a></div>
                 {{whataspp($id='1',$send='1')}}
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
 
                </div>
                <div id="msg"> </div>
                      
<table id="table" class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Create at</th>
            <th>User Type</th>
            <th width="300px;">Action</th>
        </tr>
    </thead>
    <tbody>
        @if(!empty($data) && $data->count())
            @foreach($data as $key => $value)
                <tr id="{{ $value->id }}">
                    <td>{{ $value->name }}</td>
                    <td>{{ $value->email }}</td>
                    <td>{{ $value->created_at }}</td>
                    <td>{{ $value->user_type_id==1?"Admin":"User" }}</td>
                    <td>
                        <button onclick="delete_data({{ $value->id }})" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
            @endforeach
        @else
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        @endif
    </tbody>
</table>
   
{!! $data->links() !!}
        </div>
    </div>
</div>
<script type="text/javascript">
 	function delete_data(a) {
 		 
 		$.ajax({
type: "POST", 
url:"/user_delete",
async: true,
data: { _token: $('meta[name="csrf-token"]').attr('content'), id: a },
 success:function(data){
 	console.log(data);
            $("#msg").html("");

                if (data.msg==1) {
            $("#msg").html("user deleted successfully");

                }else{
            $("#msg").html("user not deleted");
 
                }
           $('table#table tr#'+a).remove();
         }
});
return false;


	}
</script>
@endsection
