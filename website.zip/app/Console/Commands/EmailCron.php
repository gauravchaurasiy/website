<?php

namespace App\Console\Commands;
use App\log_communication;//model

 use App\User;//model
 use App\events;//model

use Illuminate\Console\Command;

class EmailCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'emails:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       
        \Log::info("Cron is working fine!");
     
       
    $commu= communication::find($c_id);
    $whatsapp=$commu->whatsapp;
    $name=$commu->name;
    $start_at=$commu->start_at;
    $event_id=$commu->event_id;
    $sms=$commu->sms;
    $email=$commu->email;
    $firebase=$commu->firebase;
    $events= Events::find($e_id);
 // dd($events);
    $event_name=$events->name;
    $event_start_at=$events->start_at;


    $data="event ".$event_name." date  ".$event_start_at." Update starus".$name." date ".$start_at;
    $user= User::all();

    if ($id>0 and $send==1) {
                
        foreach ($user as $key => $value) {
            $data1="";      
            $data2="";      
            $data3="";      
            $data4="";      
             $user_id =$value->id;
             $user_name=$value->name;
             $user_email=$value->email;
             $user_mobile=$value->phone_no;

       
        if ($email==1) {
//need user email id
       // $data3= email($id,$send,$data);
        sendmial_custome($user_email,$subject='Communication alert',$data);

        }else{
            $email=0;
        }
        
           $data=$data1."|".$data2."|".$data3."|".$data3;


            $Logs = new Logs;       
            $Logs->whatsapp = $whataspp;
            $Logs->sms = $sms;
            $Logs->email = $email;
            $Logs->firebase = $firebase;
            $Logs->user_id = $user_id;
            $Logs->events_id = $e_id;
            $Logs->communication_id = $c_id;
            $Logs->data_log = json_encode($data);
            $Logs->save();

                }       

     
            

    }

        
 


 
      
        $this->info('Demo:Cron Cummand Run successfully!');

    }
}
