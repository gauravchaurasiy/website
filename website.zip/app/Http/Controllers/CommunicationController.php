<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Communication; 
use Illuminate\Support\Facades\DB;//query execute



class CommunicationController extends Controller
{
    
       public function __construct()
    {
        $this->middleware('auth');
    }

    public function send(Request $request,$id)
    {
      
        if ($request->isMethod('post')) {
                 $e_id= $request->event_id;
                 $c_id= $request->id;

                communicarion($c_id,$e_id,$id='1',$send='1');

            }


    }
    public function index($id)
    {
    		        
    	$data["events"] = Communication::where('event_id', $id)
               ->orderBy('name', 'desc')
               ->get();
      $data["id"]=$id;

	//	dd($data);
   		return view('view_communication',array('data'=>$data));


//        return "Hello, admin!";
    }

    public function store(Request $request,$id)
    {
    	

    	  
          if ($request->isMethod('post')) {
//dd($request);
          $validatedData = $request->validate([
          'events' => 'required|max:255|min:2',
          'start_time' => 'required',
          'sms' => 'required',
          'email' => 'required',
          'whatsapp' => 'required',
          'start_time' => 'required',
          ]);
            //dd($request->all());
            $Communication = new Communication;
            $Communication->name = $request->events;
            $Communication->event_id = $id;
            $Communication->start_at = $request->start_time;
            $Communication->sms = $request->sms;
            $Communication->email = $request->email;
            $Communication->whatsapp = $request->whatsapp;
            $Communication->firebase = $request->firebase;
            $Communication->save();
            $comm_id=   DB::getPdo()->lastInsertId();
           // $data["id"]=$id;
            $data=$_POST;
            log_communication($data,$comm_id,$id);

            return  redirect('/add_communication/'.$id.'');

        }else{
          $data["id"]=$id;
        return view('/add_communication',array('data' =>$data ));
        } 

       /* if (false) {
          # code...
        }else{
        }*/

    }
    public function edit(Request $request,$id)
    {
      # code...
       


       if ($request->isMethod('post')) {
//dd($request);
          $validatedData = $request->validate([
          'events' => 'required|max:255|min:2',
          'start_time' => 'required',
          'sms' => 'required',
          'email' => 'required',
          'whatsapp' => 'required',
          'start_time' => 'required',
          ]);
            //dd($request->all());
            $Communication =  Communication::find($id);;
            $Communication->name = $request->events;
             $Communication->start_at = $request->start_time;
            $Communication->sms = $request->sms;
            $Communication->email = $request->email;
            $Communication->whatsapp = $request->whatsapp;
            $Communication->firebase = $request->firebase;
            $Communication->save();
            
           // $data["id"]=$id;

            return  redirect('/edit_communication/'.$id.'');

        }else{
           $data["events"]= Communication::find($id);
        $data["id"]=($id);
      return view('edit_communication',array('data'=>$data));
        } 


    }

    public function delete(Request $request,$id)
    {
        $Communication= Communication::find($id);
        $Communication->delete();
        return  redirect('/add_communication/'. $request->id.'');

    }

}
