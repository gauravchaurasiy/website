<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\log_user_events; 
 use Illuminate\Support\Facades\DB;//query execute


class ApiController extends Controller
{
    //
    public function delete_user_data($event_id='',$user_id='')
    {
    	if ($event_id>0 && $user_id) {
    		
    	//$log_user_events= log_user_events::find()->where(['event_id' => $event_id,'user_id' => $user_id]);

$results = DB::delete( DB::raw("delete from log_user_events where event_id='$event_id' and user_id='$user_id'") );
        // return response()->json(array("error"=>0,"sss"=>$log_user_events,"msg"=>"User event data deleted successfully."), 200);

         if ($results==1) {
        	  //return $this->sendResponse(array("error"=>0,"msg"=>"User event data deleted successfully."));
        return response()->json(array("error"=>0,"msg"=>"User event data deleted successfully."), 200);

        }else{
        return response()->json(array("error"=>1,"msg"=>"User event data Not deleted successfully."), 200);

        	// return $this->sendResponse(array("error"=>1,"msg"=>"User event data not deleted successfully."));

        }

    	}

     	

    }
}
