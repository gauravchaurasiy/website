<?php

namespace App\Http\Controllers;
use App\User; 
use App\Events; 
use App\log_user_events; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;//query execute
use Illuminate\Foundation\Validation\ValidatesRequests;
use Session;

class EventsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       // echo "index";
           $data["events"]= Events::all();
      //  dd($data);
       return view('admin_home',array('data'=>$data));


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
       // echo "create";
        $data=[];
       return view('add_events',array('data'=>$data));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function api_store_event_log($event_id='')
    {
        $data= Events::find($event_id);
        if (!empty($data)) {
            # code...
              $event_id_db=$data->id;
              $event_name_db=$data->name;
              $event_start_db=$data->start_at;
              $event_end_db=$data->end_at;
              $User= User::all();
        
        foreach ($User as $key => $value) {
           $user_id= $value->id;
           $user_name= $value->name;
           $user_email= $value->email;
           
           $log_user_events = new log_user_events;

            $log_user_events->event_name = $event_name_db;
            $log_user_events->event_id = $event_id;
            $log_user_events->start_at = $event_start_db;
            $log_user_events->end_at = $event_end_db;

            $log_user_events->user_id = $user_id;
            $log_user_events->user_name = $user_name;
            $log_user_events->user_email = $user_email;

            $log_user_events->save();
        }

        }
      

    }
    public function store(Request $request)
    {
        //

        $validatedData = $request->validate([
        'events' => 'required|max:255|min:2',
        'start_time' => 'required',
        'end_time' => 'required',
    ]);
        
         // if ($validatedData->fails()) {

            //dd("if");
              if ($request->isMethod('post')) {
            //dd($request->all());

            $Events = new Events;

            $Events->name = $request->events;
            $Events->start_at = $request->start_time;
            $Events->end_at = $request->end_time;
            $Events->save();
              $event_id=   DB::getPdo()->lastInsertId();
             $data=$_POST;
             log_events($data,$event_id);
             //dd("log");
            Session::flash('message', 'event is added !'); 
            Session::flash('alert-class', 'alert-success'); 

           return redirect('/events');
        }


        /* }else{
            dd("else");
          }*/
        

        

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        echo "show132";

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
      $data["events"]= Events::find($id);
      return view('edit_events',array('data'=>$data));


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
         $validatedData = $request->validate([
        'events' => 'required|max:255|min:2',
        'start_time' => 'required',
        'end_time' => 'required',
        ]);


          if ($request->isMethod('put')) {
            //dd($request->all());
            $Events= Events::find($id);
           // $Events = new Events;
            $Events->name = $request->events;
            $Events->start_at = $request->start_time;
            $Events->end_at = $request->end_time;
            $Events->save();
           // dd("ddd");
            Session::flash('message', 'event is Update !'); 
            Session::flash('alert-class', 'alert-success'); 
            return  redirect('/events/');
        }else{

            Session::flash('message', 'event is Update fails !'); 
            Session::flash('alert-class', 'alert-danger'); 
            return  redirect('/events/');         }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
           Session::flash('message', 'event is Delete !'); 
            Session::flash('alert-class', 'alert-danger'); 
        $Events= Events::find($id);
        $Events->delete();
        return  redirect('/events/');


    }
}
