<?php
  
 use App\User;//model
 use App\events;//model
 use App\logs;//model
 use App\communication;//model
 use App\log_communication;//model
 use App\log_events;//model
 use Illuminate\Support\Facades\DB;//query execute
 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;


function log_communication($data='',$comm_id='',$event_id='')
{			
	if (!empty($data) and count($data)>0) {

		    $log_communication = new log_communication;		
            $log_communication->data = json_encode($data);
            $log_communication->comm_id = $comm_id;
            $log_communication->event_id = $event_id;
            $log_communication->save();
	}
			
}
function log_events($data='',$event_id='')
{
		if (!empty($data) and count($data)>0) {
     			 DB::insert('insert into log_events (created_at,event_id,data) values (?,?, ?)',
                   [date("Y-m-d H:i:s"),$event_id,json_encode($data)]
                    );
                	//dd($data,$event_id);

     			 //dd("logs");
                   // $id=   DB::getPdo()->lastInsertId();
                }else{
                }
}

 function communicarion($c_id='0',$e_id='0',$id='0',$send='0')
     {
     	$commu= communication::find($c_id);
     	$whatsapp=$commu->whatsapp;
     	$name=$commu->name;
     	$start_at=$commu->start_at;
     	$event_id=$commu->event_id;
     	$whataspp=$commu->whataspp;
     	$sms=$commu->sms;
     	$email=$commu->email;
     	$firebase=$commu->firebase;
     	$events= Events::find($e_id);
     //	dd($events);
     	$event_name=$events->name;
     	$event_start_at=$events->start_at;


     	$data="event ".$event_name." date  ".$event_start_at." Update starus".$name." date ".$start_at;
    	$user= User::all();

    	if ($id>0 and $send==1) {
     				
    		foreach ($user as $key => $value) {
    			$data1="";		
    			$data2="";		
    			$data3="";		
    			$data4="";		
    			 $user_id =$value->id;
    			 $user_name=$value->name;
    			 $user_email=$value->email;
    			 $user_mobile=$value->phone_no;

    		if ($whataspp==1) {
     			//need whatsapp no
     		$data1=	whataspp($id,$send,$data);
     		}else{
     			$whataspp=0;
     		}
     		if ($sms==1) {
     			# code...///we send here mobile for sms
    		$data2=	sms($id,$send,$data);

     		}else{
     			$sms=0;
     		}
     		if ($email==1) {
            //need user email id
     		$data3=	email($id,$send,$data);

     		}else{
     			$email=0;
     		}
     		if ($firebase==1) {
     			# code...//need user firebse token 
     		$data4=	firebase($id,$send,$data);

     		}else{
     			$firebase=0;
     		}

     		   $data=$data1."|".$data2."|".$data3."|".$data3;


    			$Logs = new Logs;		
                $Logs->whatsapp = $whataspp;
                $Logs->sms = $sms;
                $Logs->email = $email;
                $Logs->firebase = $firebase;
                $Logs->user_id = $user_id;
                $Logs->events_id = $e_id;
                $Logs->communication_id = $c_id;
                $Logs->data_log = json_encode($data);
                $Logs->save();

    				}		

     	 
     			echo "close communication done";

    	}

     		
     


     }

function whataspp($id='',$send='',$data='')
{
	if ($id>0 and $send==1) {
 				
 	//$data=file_get_contents("https://www.google.co.in/");
  

	}
	
}
function firebase($id='',$send='',$data='')
{
	/*curl -X POST --header "Authorization: key=<API_ACCESS_KEY>" \
    --Header "Content-Type: application/json" \
    https://fcm.googleapis.com/fcm/send \
    -d "{\"to\":\"<YOUR_DEVICE_ID_TOKEN>\",\"notification\":{\"body\":\"Yellow\"},\"priority\":10}"

    */
	if ($id>0 and $send==1) {
 
 	//$data=file_get_contents("https://www.google.co.in/");

	}
}

function sms($id='',$send='',$data='')
{
	if ($id>0 and $send==1) {
 	//sms spi url 
 //	$data=file_get_contents("https://www.google.co.in/");

	}
}
function email($id='',$send='',$data='')
{
	if ($id>0 and $send==1) {
 
 	//$data=file_get_contents("https://www.google.co.in/");

	}

	    
}

function sendmial_custome($email='',$subject='',$body='')
            {
            /*
            MAIL_MAILER=smtp
            MAIL_HOST=mail.loanbaazaronline.com
            MAIL_PORT=465 
            MAIL_USERNAME=info@loanbaazaronline.com
            MAIL_PASSWORD=VpQazz3jAw,_
            MAIL_ENCRYPTION=ssl*/
            # code...
            //require 'vendor/autoload.php';

            $mail = new PHPMailer(true);

            try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'mail.hostname.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'inf@hostname.com';                     // SMTP username
            $mail->Password   = 'password';                               // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

            //Recipients
            $mail->setFrom('info@loanbaazaronline.com', 'Mailer');
            $mail->addAddress($email);     // Add a recipient
            //  $mail->addAddress('info@loanbaazaronline.com');               // Name is optional
            // $mail->addReplyTo('info@loanbaazaronline.com', 'Information');
            // $mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');

            // Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body    = $body;
            // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            echo 'Message has been sent';
            } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }


}