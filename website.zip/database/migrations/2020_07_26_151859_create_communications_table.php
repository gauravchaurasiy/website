<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommunicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('communications', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->dateTime('start_at'); 
            $table->integer('event_id')->default('0');
            $table->integer('sms')->default('0');
            $table->integer('email')->default('0');
            $table->integer('firebase')->default('0');
            $table->integer('whatsapp')->default('0');
            $table->integer('active')->default('0');
            $table->string('delete_at')->default('0');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('communications');
    }
}
